package id.ac.itn.mhsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.util.List;

import id.ac.itn.mhsapp.adapter.MahasiswaAdapter;
import id.ac.itn.mhsapp.model.Mahasiswa;
import id.ac.itn.mhsapp.model.MahasiswaViewModel;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    RecyclerView recyclerView;
    MahasiswaAdapter adapter;

    List<Mahasiswa> mhsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        MahasiswaViewModel mhsViewModel = ViewModelProviders.of(this).get(MahasiswaViewModel.class);
        mhsViewModel.getListMhs().observe(this, new Observer<List<Mahasiswa>>() {

            @Override
            public void onChanged(List<Mahasiswa> mhsList) {
                adapter = new MahasiswaAdapter(MainActivity.this, mhsList);
                recyclerView.setAdapter(adapter);
                Log.d(TAG, "onChanged: set AdapterMhs");
            }
        });
    }
}
