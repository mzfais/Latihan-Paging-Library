package id.ac.itn.mhsapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import id.ac.itn.mhsapp.R;
import id.ac.itn.mhsapp.model.Mahasiswa;

public class MhsPagedAdapter extends PagedListAdapter<Mahasiswa,MhsPagedAdapter.MhsViewHolder> {
    private Context mCtx;

    protected MhsPagedAdapter(Context mCtx) {
        super(DIFF_CALLBACK);
        this.mCtx = mCtx;
    }

    @NonNull
    @Override
    public MhsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.mhs_list_item, parent, false);
        return new MhsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MhsViewHolder holder, int position) {
        Mahasiswa mhs = getItem(position);
        if(mhs !=null) {
            holder.tvnim.setText(mhs.getNim());
            holder.tvnama.setText(mhs.getNama());
        }else{
            Toast.makeText(mCtx,"Data Mahasiswa tidak ditemukan",Toast.LENGTH_SHORT).show();
        }
    }

    private static DiffUtil.ItemCallback<Mahasiswa> DIFF_CALLBACK = new DiffUtil.ItemCallback<Mahasiswa>() {
        @Override
        public boolean areItemsTheSame(@NonNull Mahasiswa oldItem, @NonNull Mahasiswa newItem) {
            return oldItem.getNim() == newItem.getNim();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Mahasiswa oldItem, @NonNull Mahasiswa newItem) {
            return oldItem.equals(newItem);
        }
    };

    public class MhsViewHolder extends RecyclerView.ViewHolder {
        TextView tvnim, tvnama;

        public MhsViewHolder(@NonNull View itemView) {
            super(itemView);
            tvnim = itemView.findViewById(R.id.tvNim);
            tvnama = itemView.findViewById(R.id.tvNama);
        }
    }
}
